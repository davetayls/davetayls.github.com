var disallowedGlobalFunctionWithNoSemiColon = function(){
	alert('fail');
}
