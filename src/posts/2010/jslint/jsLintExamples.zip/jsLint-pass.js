String.prototype.alert = function(){
	window.alert(this);
};
